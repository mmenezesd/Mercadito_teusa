<?php include "conexao.php"?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar Produto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col">

<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  if (!isset($_GET['id_produto']) || !ctype_digit($_GET['id_produto'])) {
    echo '<script>alert("ID inválido."); window.location.href = "produtoconsulta.php";</script>';
    exit;
  }

  $id = (int) $_GET['id_produto'];
  $sql = "SELECT id_produto, no_produto, de_produto, no_situacao, vl_preco, qt_estoque FROM produto WHERE id_produto = ? LIMIT 1";
  $stmt = mysqli_prepare($conn, $sql);
  if ($stmt === false) {
    error_log('Prepare failed in produtoeditar.php (GET): ' . mysqli_error($conn));
    echo '<script>alert("Erro na consulta."); window.location.href = "produtoconsulta.php";</script>';
    exit;
  }
  mysqli_stmt_bind_param($stmt, 'i', $id);
  mysqli_stmt_execute($stmt);
  $res = mysqli_stmt_get_result($stmt);
  $row = mysqli_fetch_assoc($res);
  mysqli_stmt_close($stmt);

  if (!$row) {
    echo '<script>alert("Produto não encontrado."); window.location.href = "produtoconsulta.php";</script>';
    exit;
  }

  $no_produto = htmlspecialchars($row['no_produto']);
  $de_produto = htmlspecialchars($row['de_produto']);
  $no_situacao = $row['no_situacao'];
  $vl_preco = $row['vl_preco'];
  $qt_estoque = (int)$row['qt_estoque'];

  // Exibir form preenchido
  echo '<div class="card w-75" style="margin:auto; margin-top:20px;">';
  echo '<div class="card-body title text-center bg-dark text-white"><h2>Editar Produto</h2></div>';
  echo '<div class="card-body p-3" style="background-color: #bfbafa;">';
  echo '<form action="produtoeditar.php" method="POST">';
  echo '<input type="hidden" name="id_produto" value="'. $id .'">';

  echo '<div class="mb-3"><label class="form-label"><strong>Nome do Produto</strong></label>'; 
  echo '<input type="text" name="no_produto" class="form-control" value="'. $no_produto .'" required></div>';

  echo '<div class="mb-3"><label class="form-label"><strong>Descrição</strong></label>'; 
  echo '<textarea name="de_produto" class="form-control" rows="3">'. $de_produto .'</textarea></div>';

  echo '<div class="mb-3"><label class="form-label"><strong>Situação</strong></label>'; 
  echo '<select name="no_situacao" class="form-control">';
  echo '<option value="Ativo"'.($no_situacao==='Ativo'?' selected':'').'>Ativo</option>';
  echo '<option value="Inativo"'.($no_situacao==='Inativo'?' selected':'').'>Inativo</option>';
  echo '</select></div>';

  echo '<div class="mb-3"><label class="form-label"><strong>Preço</strong></label>'; 
  echo '<input type="number" step="0.01" min="0" name="vl_preco" class="form-control" value="'. $vl_preco .'"></div>';

  echo '<div class="mb-3"><label class="form-label"><strong>Quantidade</strong></label>'; 
  echo '<input type="number" step="1" min="0" name="qt_estoque" class="form-control" value="'. $qt_estoque .'"></div>';

  echo '<div class="mb-3">';
  echo '<button class="btn btn-success btn-sm" type="submit">Salvar</button> ';
  echo '<a href="produtoconsulta.php" class="btn btn-secondary btn-sm">Cancelar</a>';
  echo '</div>';

  echo '</form></div></div>';

  exit;
}

// POST -> atualizar registro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = isset($_POST['id_produto']) && ctype_digit($_POST['id_produto']) ? (int)$_POST['id_produto'] : 0;
  $no_produto = isset($_POST['no_produto']) ? trim($_POST['no_produto']) : '';
  $de_produto = isset($_POST['de_produto']) ? trim($_POST['de_produto']) : '';
  $no_situacao = isset($_POST['no_situacao']) ? trim($_POST['no_situacao']) : 'Ativo';
  $vl_preco = isset($_POST['vl_preco']) ? trim($_POST['vl_preco']) : '';
  $qt_estoque = isset($_POST['qt_estoque']) ? trim($_POST['qt_estoque']) : '';

  if ($id <= 0 || $no_produto === '') {
    echo '<script>alert("Dados inválidos."); window.location.href = "produtoconsulta.php";</script>';
    exit;
  }

  if ($vl_preco === '' || !is_numeric($vl_preco) || $vl_preco < 0) {
    echo '<script>alert("Preço inválido."); window.location.href = "produtoeditar.php?id_produto=' . $id . '";</script>';
    exit;
  }

  if ($qt_estoque === '' || !ctype_digit($qt_estoque)) {
    echo '<script>alert("Quantidade inválida."); window.location.href = "produtoeditar.php?id_produto=' . $id . '";</script>';
    exit;
  }

  $sql = "UPDATE produto SET no_produto = ?, de_produto = ?, no_situacao = ?, vl_preco = ?, qt_estoque = ? WHERE id_produto = ?";
  $stmt = mysqli_prepare($conn, $sql);
  if ($stmt === false) {
    error_log('Prepare failed in produtoeditar.php (POST): ' . mysqli_error($conn));
    echo '<script>alert("Erro ao atualizar."); window.location.href = "produtoconsulta.php";</script>';
    exit;
  }

  $vl_preco_f = (float)$vl_preco;
  $qt_int = (int)$qt_estoque;
  mysqli_stmt_bind_param($stmt, 'sssdis', $no_produto, $de_produto, $no_situacao, $vl_preco_f, $qt_int, $id);

  if (mysqli_stmt_execute($stmt)) {
    echo '<script>alert("Produto atualizado com sucesso."); window.location.href = "produtoconsulta.php";</script>';
  } else {
    error_log('Update failed in produtoeditar.php: ' . mysqli_stmt_error($stmt));
    echo '<script>alert("Erro ao atualizar."); window.location.href = "produtoeditar.php?id_produto=' . $id . '";</script>';
  }

  mysqli_stmt_close($stmt);
}
?>

        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  </body>
</html>
