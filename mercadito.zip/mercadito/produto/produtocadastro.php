<?php include "conexao.php"?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <title>Cadastro Produto</title>
  </head>
  <body>
    <?php
      // Ler campos do POST com checagem
      $no_produto = isset($_POST['no_produto']) ? trim($_POST['no_produto']) : '';
      $de_produto = isset($_POST['de_produto']) ? trim($_POST['de_produto']) : '';
      $no_situacao = isset($_POST['no_situacao']) ? trim($_POST['no_situacao']) : 'Ativo';
      $vl_preco = isset($_POST['vl_preco']) ? trim($_POST['vl_preco']) : '';
      $qt_estoque = isset($_POST['qt_estoque']) ? trim($_POST['qt_estoque']) : '';
      $dt_cadastro = date('Y-m-d');

      // Validações
      if ($no_produto === '') {
        echo '<script>alert("Informe o nome do produto!"); window.location.href = "produto_page.php";</script>';
        exit;
      }

      if ($vl_preco === '' || !is_numeric($vl_preco) || $vl_preco < 0) {
        echo '<script>alert("Preço inválido!"); window.location.href = "produto_page.php";</script>';
        exit;
      }

      if ($qt_estoque === '' || !ctype_digit($qt_estoque)) {
        echo '<script>alert("Quantidade inválida!"); window.location.href = "produto_page.php";</script>';
        exit;
      }

      // Prepared statement
      $sql = "INSERT INTO produto (no_produto, de_produto, no_situacao, vl_preco, qt_estoque, dt_cadastro) VALUES (?, ?, ?, ?, ?, ?)";
      $stmt = mysqli_prepare($conn, $sql);
      if ($stmt === false) {
        error_log('Prepare failed in produtocadastro.php: ' . mysqli_error($conn));
        echo '<script>alert("Erro no cadastro. Tente novamente."); window.location.href = "produto_page.php";</script>';
        exit;
      }

      // bind: s s s d i s
      $vl_preco_float = (float) $vl_preco;
      $qt_estoque_int = (int) $qt_estoque;

      mysqli_stmt_bind_param($stmt, 'sssdis', $no_produto, $de_produto, $no_situacao, $vl_preco_float, $qt_estoque_int, $dt_cadastro);

      if (mysqli_stmt_execute($stmt)) {
        echo '<script>alert("Produto cadastrado com sucesso"); window.location.href = "produto_page.php";</script>';
      } else {
        error_log('Insert failed in produtocadastro.php: ' . mysqli_stmt_error($stmt));
        echo '<script>alert("Erro no cadastro. Tente novamente."); window.location.href = "produto_page.php";</script>';
      }

      mysqli_stmt_close($stmt);
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  </body>
</html>
