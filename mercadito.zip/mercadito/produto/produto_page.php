<!doctype html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Página 2</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>
    <body>
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">
                <a class="navbar-brand" href="../index.php">Mercadito</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="../index.php">Página Inicial</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container"> <!-- Componente BootStrap --> 
            <div  class="row"><!-- Linhas 1-->
                <div class="col"> <!-- Colunas 1 PRINCIPAL-->   
                    <div class="card w-75 text-align: center" style="margin:auto;" > 
                        <div class="card-body title text-center" style="background-color:rgb(0, 0, 0);color:white; ">
                            <h1 class="card-title">Cadastro de Produto</h1>
                        </div>
                    </div>

                    <div class="card-body w-75 p-3" style="background-color:rgb(191, 186, 250); margin:auto;">
                        <form action="produtocadastro.php" method="POST">
                            <div class="row">
                                <div class="col-md-8">
                                    <label for="no_produto" class="form-label"><strong> Nome do Produto</strong></label>
                                    <input type="text" class="form-control" placeholder="Nome do produto" name="no_produto" required>
                                </div>
                                <div class="col-xs-6 col-md-4">
                                    <label class="col-md-12"><strong>Situação</strong></label>
                                    <select name="no_situacao" id="no_situacao" class="form-control">
                                        <option value="Ativo">Ativo</option>
                                        <option value="Inativo">Inativo</option>
                                    </select>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-md-12">
                                    <label for="de_produto" class="form-label"><strong> Descrição</strong></label>
                                    <textarea class="form-control" name="de_produto" placeholder="Descrição do produto" rows="3"></textarea>
                                </div>
                            </div>

                            <div class="row mt-3">
                                <div class="col-md-4">
                                    <label for="vl_preco" class="form-label"><strong> Preço</strong></label>
                                    <input type="number" step="0.01" min="0" class="form-control" placeholder="0.00" name="vl_preco" required>
                                </div>
                                <div class="col-md-4">
                                    <label for="qt_estoque" class="form-label"><strong> Quantidade</strong></label>
                                    <input type="number" step="1" min="0" class="form-control" placeholder="0" name="qt_estoque" required>
                                </div>
                                <div class="col-md-4 d-flex align-items-end">
                                    <div class="w-100">
                                        <button class="btn btn-success btn-sm w-100" type="submit">Gravar</button>
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-12">
                                    <a href="produtoconsulta.php" class="btn btn-primary btn-sm">Consulta</a>
                                    <a href="../index.php" class="btn btn-dark btn-sm">Home</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    </body>
</html>