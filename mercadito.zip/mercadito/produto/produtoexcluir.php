<?php include "conexao.php"?>
<?php
  if (!isset($_GET['id_produto']) || !ctype_digit($_GET['id_produto'])) {
    echo '<script>alert("ID inválido."); window.location.href = "produtoconsulta.php";</script>';
    exit;
  }

  $id = (int) $_GET['id_produto'];

  $sql = "DELETE FROM produto WHERE id_produto = ?";
  $stmt = mysqli_prepare($conn, $sql);
  if ($stmt === false) {
    error_log('Prepare failed in produtoexcluir.php: ' . mysqli_error($conn));
    echo '<script>alert("Erro ao excluir. Tente novamente."); window.location.href = "produtoconsulta.php";</script>';
    exit;
  }

  mysqli_stmt_bind_param($stmt, 'i', $id);
  if (mysqli_stmt_execute($stmt)) {
    echo '<script>alert("Produto excluído com sucesso."); window.location.href = "produtoconsulta.php";</script>';
  } else {
    error_log('Delete failed in produtoexcluir.php: ' . mysqli_stmt_error($stmt));
    echo '<script>alert("Erro ao excluir. Tente novamente."); window.location.href = "produtoconsulta.php";</script>';
  }

  mysqli_stmt_close($stmt);
?>