<?php
$server = "localhost";
$user = "root";
$pswd = "";
$bd = "valdosque_bd";

if ($conn = mysqli_connect($server, $user, $pswd, $bd)) {
    // Conexão estabelecida com sucesso
    // echo "Banco de dados " . $bd . " conectado com sucesso!";
} else {
    echo "Erro de conexão com o banco de dados!";
    echo "<br>Erro: " . mysqli_connect_error();
}
?>
