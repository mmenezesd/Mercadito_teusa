<?php include "conexao.php"; ?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Consulta Produto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script>
      function checkDelete(){
        return confirm('Confirma exclusão?');
      }
    </script>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card w-100" style="margin-top:20px;">
            <div class="card-body title text-center bg-dark text-white">
              <h1 class="card-title">Consulta Produto</h1>
            </div>
            <div class="card-body" style="background-color:#7b7e7c;">
              <form action="produtoconsulta.php" method="POST" class="row g-2 align-items-center">
                <div class="col-auto">
                  <label for="no_produto" class="form-label text-white">Nome</label>
                </div>
                <div class="col-auto">
                  <input type="text" name="no_produto" id="no_produto" class="form-control" placeholder="Pesquisar por nome">
                </div>
                <div class="col-auto">
                  <button class="btn btn-success btn-sm" type="submit">Pesquisar</button>
                  <a href="produto_page.php" class="btn btn-primary btn-sm">Novo</a>
                  <a href="../index.php" class="btn btn-dark btn-sm">Home</a>
                </div>
              </form>
            </div>

            <div class="card-body">
              <?php
                $pesquisar = '';
                if (isset($_POST['no_produto'])) {
                  $pesquisar = trim($_POST['no_produto']);
                }

                $sql = "SELECT id_produto, no_produto, no_situacao, vl_preco, qt_estoque, dt_cadastro FROM produto WHERE no_produto LIKE ? ORDER BY no_produto ASC";
                $stmt = mysqli_prepare($conn, $sql);
                if ($stmt === false) {
                  echo '<div class="alert alert-danger">Erro na consulta.</div>';
                } else {
                  $like = "%" . $pesquisar . "%";
                  mysqli_stmt_bind_param($stmt, 's', $like);
                  mysqli_stmt_execute($stmt);
                  $result = mysqli_stmt_get_result($stmt);

                  echo '<table class="table table-bordered">';
                  echo '<thead class="table-dark"><tr><th>Código</th><th>Nome</th><th>Situação</th><th>Preço</th><th>Estoque</th><th>Dt.Cadastro</th><th>Ações</th></tr></thead>';
                  echo '<tbody>';

                  while ($row = mysqli_fetch_assoc($result)) {
                    $id = $row['id_produto'];
                    $nome = htmlspecialchars($row['no_produto']);
                    $sit = htmlspecialchars($row['no_situacao']);
                    $preco = number_format($row['vl_preco'], 2, ',', '.');
                    $qt = (int) $row['qt_estoque'];
                    $dt = $row['dt_cadastro'] ? date('d/m/Y', strtotime($row['dt_cadastro'])) : '';

                    echo "<tr>";
                    echo "<td class='text-center'>". $id ."</td>";
                    echo "<td>". $nome ."</td>";
                    echo "<td class='text-center'>". $sit ."</td>";
                    echo "<td class='text-right'>R$ ". $preco ."</td>";
                    echo "<td class='text-center'>". $qt ."</td>";
                    echo "<td class='text-center'>". $dt ."</td>";
                    echo "<td class='text-center'>
                            <a href='produtoeditar.php?id_produto=".$id."' class='btn btn-sm btn-warning'>Editar</a>
                            <a href='produtoexcluir.php?id_produto=".$id."' class='btn btn-sm btn-danger' onclick='return checkDelete()'>Excluir</a>
                          </td>";
                    echo "</tr>";
                  }

                  echo '</tbody></table>';

                  mysqli_stmt_close($stmt);
                }
              ?>
            </div>

          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  </body>
</html>
