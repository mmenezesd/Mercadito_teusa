-- Cria tabela produto usada pelo sistema
CREATE TABLE IF NOT EXISTS produto (
  id_produto INT AUTO_INCREMENT PRIMARY KEY,
  no_produto VARCHAR(255) NOT NULL,
  de_produto TEXT,
  no_situacao VARCHAR(20) DEFAULT 'Ativo',
  vl_preco DECIMAL(10,2) DEFAULT 0.00,
  qt_estoque INT DEFAULT 0,
  dt_cadastro DATE,
  INDEX idx_no_produto (no_produto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
