<?php
$server = "localhost";
$user = "root";
$pswd = "";
$bd = "valdosque_bd";

if ($conn= mysqli_connect($server, $user, $pswd, $bd)){
    // echo "Banco de dados", $bd, "conectado";
}
else {
    echo "Erro de conexão com o banco de dados!";
}
?>

