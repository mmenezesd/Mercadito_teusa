<?php include "conexao.php"?> 
<!doctype html>
  <html lang="pt-br"> <!-- Configura a idioma da página HTML -->
    <head>
      <meta charset="utf-8"> <!--Garante que o conteúdo seja exibido corretamente em diferentes plataformas --> 
      <meta name="viewport" content="width=device-width, initial-scale=1"> <!--Otimiza a exibição de uma página web em diferentes dispositivos -->   
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>
    <body>
      <?php
        // Carregar os campos com checagem segura
        $no_cliente   = isset($_POST['no_cliente'])   ? trim($_POST['no_cliente'])   : '';
        $no_situacao  = isset($_POST['no_situacao'])  ? trim($_POST['no_situacao'])  : '';
        $no_endereco  = isset($_POST['no_endereco'])  ? trim($_POST['no_endereco'])  : '';
        $no_bairro    = isset($_POST['no_bairro'])    ? trim($_POST['no_bairro'])    : '';
        $no_cidade    = isset($_POST['no_cidade'])    ? trim($_POST['no_cidade'])    : '';
        $no_uf        = isset($_POST['no_uf'])        ? trim($_POST['no_uf'])        : '';
        $no_email     = isset($_POST['no_email'])     ? trim($_POST['no_email'])     : '';
        $nu_dddtel    = isset($_POST['nu_dddtel'])    ? trim($_POST['nu_dddtel'])    : '';
        $nu_telefone  = isset($_POST['nu_telefone'])  ? trim($_POST['nu_telefone'])  : '';
        $dt_cadastro  = date('Y-m-d');

        // Validações simples e amigáveis
        if ($no_cliente === '') {
          echo '<script type="text/javascript">';
          echo 'alert("Informe nome do Cliente!");';
          echo 'window.location.href = "clientepage.php";';
          echo '</script>';
          exit;
        }

        if ($no_email !== '' && !filter_var($no_email, FILTER_VALIDATE_EMAIL)) {
          echo '<script type="text/javascript">';
          echo 'alert("Email inválido!");';
          echo 'window.location.href = "clientepage.php";';
          echo '</script>';
          exit;
        }

        // Validação leve de telefone (permite dígitos, espaços, parênteses e traço)
        if ($nu_telefone !== '' && !preg_match('/^[0-9\\-\\s\\(\\)]+$/', $nu_telefone)) {
          echo '<script type="text/javascript">';
          echo 'alert("Telefone inválido!");';
          echo 'window.location.href = "clientepage.php";';
          echo '</script>';
          exit;
        }

        // Prepared statement para evitar SQL injection
        $sql = "INSERT INTO cliente (no_cliente, no_situacao, no_endereco, no_bairro, no_cidade, no_uf, no_email, nu_dddtel, nu_telefone, dt_cadastro)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt === false) {
          // Log do erro para o administrador / desenvolvedor
          error_log("Prepare failed in clientecadastro.php: " . mysqli_error($conn));
          echo '<script type="text/javascript">';
          echo 'alert("Erro no cadastro. Tente novamente.");';
          echo 'window.location.href = "clientepage.php";';
          echo '</script>';
          exit;
        }

        // Bind dos parâmetros: todos strings (s)
        mysqli_stmt_bind_param($stmt, 'ssssssssss',
          $no_cliente, $no_situacao, $no_endereco, $no_bairro, $no_cidade, $no_uf, $no_email, $nu_dddtel, $nu_telefone, $dt_cadastro
        );

        if (mysqli_stmt_execute($stmt)) {
          echo '<script type="text/javascript">';
          echo 'alert("Cadastro realizado com sucesso");';
          echo 'window.location.href = "clientepage.php";';
          echo '</script>';
        } else {
          // Log do erro real no servidor; mensagem genérica para o usuário
          error_log("Insert failed in clientecadastro.php: " . mysqli_stmt_error($stmt));
          echo '<script type="text/javascript">';
          echo 'alert("Erro no cadastro. Tente novamente.");';
          echo 'window.location.href = "clientepage.php";';
          echo '</script>';
        }

        mysqli_stmt_close($stmt);
      ?>             
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
    </body>
  </html>