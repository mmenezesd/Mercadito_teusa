   <?php include "../webservice/conexao.php"; ?> 
<!doctype html>
<html lang="pt-br"> <!-- Configura a idioma da página HTML -->
  <head>
    <meta charset="utf-8"> <!--Garante que o conteúdo seja exibido corretamente em diferentes plataformas --> 
    <meta name="viewport" content="width=device-width, initial-scale=1"> <!--Otimiza a exibição de uma página web em diferentes dispositivos -->
    <title>Chamados</title>  <!-- Titulo da aba do navegador-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <!--Confirma exclusão --> 
    <script language="JavaScript" type="text/javascript">
            function checkDelete(){
            return confirm('Confirma exclusão?');
            }
    </script>

  </head>
  <body>  
    <!--  Filtro -->      
    <?php
      //Primeira forma de pesquisa
      if (isset($_POST['no_cliente'])){
        $pesquisar = TRIM($_POST['no_cliente']);
      }
      else{
        $pesquisar = '';
      }      
      $sql = "SELECT id_cliente, no_cliente, no_situacao, nu_dddtel, nu_telefone, dt_cadastro  FROM cliente   WHERE no_cliente like '%$pesquisar%' ORDER BY no_cliente  ASC";
      // Executa o sql
      $dados = mysqli_query($conn, $sql);
      //var_dump($sql);
    ?> 
    <div class="container" > 
        <div  class="row">
            <div class="col">   
                <!-- Card-->                 
                <div class="card w-10 text-align: center" > <!-- Tamanho/alinha  do Card --> 
                      <div class="card-body title text-center" style="background-color:rgb(0, 0, 0);color:white">
                        <h1 class="card-title">Consulta Cliente </h1> <!-- Contante com o TITULO do site--> 
                      </div> 
                        <!-- Campos para consulta" -->  
                      <div class="card-body title text-left" style="background-color:rgb(123, 126, 124);">  
                            <nav class="navbar bg-body-tertiary">
                                <div class="container-fluid">
                                    <form class="form-inline" action="clienteconsulta.php" method="POST">
                                          <div class="container text-center">
                                              <div class="row align-items-start">
                                                  <div class="col col-md-2" style="text-align: left;">
                                                      <label  for="no_cliente" class="form-label"><strong> Nome</strong></label>                                        
                                                  </div>
                                                  <div class="col col-md-12" style="text-align: left;">
                                                      <input type="text" style="border: 2px solid blue; font-weight: bold" class="form-control" size="15"   maxlength="20"   name="no_cliente" id="no_cliente"/> 
                                                  </div>
                                                  <div class="col col-md-6" style="text-align: left;">
                                                      <button class="btn btn-success btn-sm" type="submit">Consultar</button> 
                                                      <a href="clientepage.php" class="btn btn-primary btn-sm">Voltar</a>  
                                                      <a href="../index.php" class="btn btn-dark btn-sm">Home</a> 
                                                  </div>
                                              </div>
                                          </div>  
                                    </form>
                                </div> <!-- div class="container-fluid" -->
                            </nav> <!-- nav class="navbar b -->
                      </div>  <!-- lass="card-body title text-left" -->  
                      
                       <!-- Dados da consulta" -->  
                      <!-- <div class="card-body title text-left" style="background-color:rgb(123, 126, 124);">   -->
                                <div class="container-fluid">
                                    <table class="table table-bordered"> <!-- tabela onde ficara o resultado da consulta -->
                                         <thead class="table-dark">
                                            <tr> 
                                              <th scope="col"  class="text-center" style="height: 10px; font-size: 14px; width:  10px; height: 2px;" ><strong> Código</th>                                               
                                               <th scope="col" class="text-left" style="height: 10px; font-size: 14px;  width: 780px; height: 2px;"> Nome </th>
                                               <th scope="col" class="text-center" style="height: 10px; font-size: 14px;  width: 100px; height: 2px;"> Situção </th>  
                                               <th scope="col" class="text-left" style="height: 10px; font-size: 14px;  width: 180; height: 2px;"> Telefone </th>  
                                               <th scope="col" class="text-left" style="height: 10px; font-size: 14px;  width: 150; height: 2px;"> Dt.Cadastro </th>                                                                                                
                                               <th scope="col" class="text-center" style="text-align: right; font-size: 14px;  width: 20px; height: 16px;"> Operação  </th>  

                                            </tr>
                                        </thead>
                                        <tbody><!-- Coluna de dados da consulta -->
                                            <?php
                                                if($sql === FALSE) {
                                                        // Consulta falhou, parar aqui 
                                                        die(mysqli_error($conn));
                                                    }
                                                    else{            
                                                        while ($linha = mysqli_fetch_assoc($dados) ) { 
                                                            $id_cliente = $linha['id_cliente'];        
                                                            $no_cliente = $linha['no_cliente'];
                                                            $no_situacao = $linha['no_situacao'];                                                            
                                                            $nu_telefone = '('.$linha['nu_dddtel'].') '.$linha['nu_telefone'];
                                                            $dt_cadastro = substr($linha['dt_cadastro'], 8, 2).'/'.substr($linha['dt_cadastro'], 5, 2).'/'.substr($linha['dt_cadastro'], 0, 4);                            
                                                           //$dt_cadastro = $linha['dt_cadastro']; 
                                                            echo"<tr>
                                                                <th scope='row' class='text-center' style='height: 10px; font-size: 14px; border: 1px solid black;' >".$id_cliente."</th>
                                                                    <td class='text-left' style='height: 10px; font-size: 14px; border: 1px solid black;'>".$no_cliente."</td> 
                                                                    <td class='text-center'style='height: 10px; font-size: 14px; border: 1px solid black;'>".$no_situacao."</td> 
                                                                    <td class='text-left'style='height: 25px; font-size: 14px; border: 1px solid black;'>".$nu_telefone."</td>  
                                                                    <td class='text-center'style='height: 10px; font-size: 14px; border: 1px solid black;'>".$dt_cadastro."</td>                                                                      
                                                                    <td style='height: 10px; font-size: 14px; border: 1px solid red;'>  <a href='clienteexcluir.php?id_cliente=".$id_cliente."' class='btn btn-danger  btn-sm' onclick='return checkDelete()'>Delete</a> </td>  
                                                                <th>
                                                            </tr>" ;


                                                        };                                                  
                                                    };
                                            ?>   
                                                                          
                                        </tbody>
                                    </table>                                    
                                                        
                                </div> <!-- div class="container-fluid" -->

                       <!--</div>   lass="card-body title text-left" -->   
                            
                    </div> <!-- div class="card w-50 tex -->
                    
                </div>

            </div>
            
        </div>

    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>
    
  </body>

</html>     

