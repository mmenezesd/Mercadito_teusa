<?php include "conexao.php"?>
<?php
  if (!isset($_GET['id_cliente']) || !ctype_digit($_GET['id_cliente'])) {
    echo '<script>alert("ID inválido."); window.location.href = "clienteconsulta.php";</script>';
    exit;
  }

  $id = (int) $_GET['id_cliente'];

  $sql = "DELETE FROM cliente WHERE id_cliente = ?";
  $stmt = mysqli_prepare($conn, $sql);
  if ($stmt === false) {
    error_log('Prepare failed in clienteexcluir.php: ' . mysqli_error($conn));
    echo '<script>alert("Erro ao excluir. Tente novamente."); window.location.href = "clienteconsulta.php";</script>';
    exit;
  }

  mysqli_stmt_bind_param($stmt, 'i', $id);
  if (mysqli_stmt_execute($stmt)) {
    echo '<script>alert("Cliente excluído com sucesso."); window.location.href = "clienteconsulta.php";</script>';
  } else {
    error_log('Delete failed in clienteexcluir.php: ' . mysqli_stmt_error($stmt));
    echo '<script>alert("Erro ao excluir. Tente novamente."); window.location.href = "clienteconsulta.php";</script>';
  }

  mysqli_stmt_close($stmt);
?>
