<!doctype html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Cliente</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    </head>
    <body>
<div class="container"> <!-- Componente BootStrap --> 
    <div  class="row"><!-- Linhas 1-->
        <!-- Titulo da pagina -->
            <div  class="row container-fluid text-center"><!-- Linhas criadas a partir do css-->                
                <div class="text-bg-dark p-3"><h1>Cliente</h1></div>   
                <div class="progress" role="progressbar" aria-label="Basic example" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">
                    <div class="progress-bar" style="width: 100%"></div>
                </div>
            </div>   
            <div class="col"> <!-- Colunas 1 PRINCIPAL-->   
                <div class="card w-75 text-align: center" style="margin:auto;" > 
        <!-- TITULO -->                
            <div class="card-body title text-center" style="background-color:rgb(0, 0, 0);color:white; ">
                <div  class="row container-fluid text-center ">
                    <h2 class="card-title">Cadastro</h2> 
                </div>                                        
            </div>                      
            </div>
        <!-- CARD DADOS -->    
            <div class="card-body w-75 p-3" style="background-color:rgb(191, 186, 250); margin:auto;">                      
            <!--formulário de dados -->
                <form action="clientecadastro.php" method="POST">                      
                            <div class="row">  
                    <!-- CAMPO NOME-->                                    
                        <div  class="col-md-10"> 
                            <label for="no_cliente" class="form-label"><strong> Nome</strong></label>
                            <input type="text" class="form-control" placeholder="Nome completo" name="no_cliente" required="required">
                        </div>   
                    <!-- CAMPO SITUAÇÃO-->                                    
                        <div class="col-xs-6 col-md-2"> <!-- Coluna--> 
                            <label class="col-md-12"><strong>Situação</strong></label>
                            <select name="no_situacao" id="no_situacao" class="form-control">
                                <option value="Ativo">Ativo</option>
                                <option value="Inativo">Inativo</option>
                            </select>                                          
                        </div>  
                        </div><!-- ROW-->                            
                        <div class="row">  
                    <!-- CAMPO BAIRRO-->                                    
                        <div  class="col-md-6"> 
                            <label for="no_bairro" class="form-label"><strong> Bairro</strong></label>
                            <input type="text" class="form-control" placeholder="Bairro" name="no_bairro">
                        </div>   
                    <!-- CAMPO CIDADE-->                                    
                        <div  class="col-md-6"> 
                            <label for="no_cidade" class="form-label"><strong> Cidade</strong></label>
                            <input type="text" class="form-control" placeholder="Cidade" name="no_cidade">
                        </div>   
                        <div class="col-xs-6 col-md-2"> <!-- Coluna--> 
                            <label class="col-md-4"><strong>UF</strong></label>
                            <select name="no_uf" id="no_uf" class="form-control">
                                <option value="AC">AC</option>
                                <option value="AL">AL</option>
                                <option value="AM">AM</option>
                                <option value="AP">AP</option>
                                <option value="BA">BA</option>
                                <option value="CE">CE</option>
                                <option value="DF">DF</option>
                                <option value="ES">ES</option>
                                <option value="GO">GO</option>
                                <option value="MA">MA</option>
                                <option value="MT">MT</option>
                                <option value="MS">MS</option>
                                <option value="MG">MG</option>
                                <option value="PA">PA</option>
                                <option value="PB">PB</option>
                                <option value="PR">PR</option>
                                <option value="PE">PE</option>
                                <option value="PI">PI</option>
                                <option value="RJ">RJ</option>
                                <option value="RN">RN</option>
                                <option value="RO">RO</option>
                                <option value="RS">RS</option>
                                <option value="RR">RR</option>
                                <option value="SC">SC</option>
                                <option value="SE">SE</option>
                                <option value="SP">SP</option>
                                <option value="TO">TO</option>
                            </select>
                        </div>  
                        <div  class="col-md-10"> 
                            <label for="no_endereco" class="form-label"><strong> Endereço</strong></label>
                            <input type="text" class="form-control" placeholder="Endereco" name="no_endereco" required="required">
                        </div>   
                        <div  class="col-md-5"> 
                            <label for="no_email" class="form-label"><strong> Email</strong></label>
                            <input type="email" class="form-control" placeholder="Email" name="no_email" required="required">
                        </div>   
                        <div  class="col-md-2"> 
                            <label for="nu_dddtel" class="form-label"><strong>DDD</strong></label>
                            <input type="tel" inputmode="numeric" pattern="[0-9]{2}" class="form-control" placeholder="DDD" name="nu_dddtel" maxlength="2" required>
                        </div>  
                        <div  class="col-md-5"> 
                            <label for="nu_telefone" class="form-label"><strong> Telefone</strong></label>
                            <input type="tel" inputmode="numeric" pattern="[0-9]{8,9}" class="form-control" placeholder="Telefone" name="nu_telefone" maxlength="9" required>
                        </div>
                        </div><!-- ROW-->           
                    <!-- BOTÕES-->     
                        <div class="card-body title text-left mt-2" style="background-color:rgb(191, 186, 250);color:white">
                            <div class="form-group">
                                <button class="btn btn-success  btn-sm" type="submit">Gravar</button>
                                <a href="clienteconsulta.php" class="btn btn-primary  btn-sm">Consulta</a>  
                                <a href="../index.php" class="btn btn-dark   btn-sm">Home</a>
                            </div>
                        </div>      
                </form>
            </div><!-- CARD DADOS --> 
            </div> <!-- Colunas 1 PRINCIPAL-->        
            </div><!-- Linhas 1--> 
</div> <!-- 1 - <div class="container"> -->         
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>

            

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    </body>
</html>