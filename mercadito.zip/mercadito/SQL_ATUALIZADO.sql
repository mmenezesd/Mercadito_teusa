-- ============================================
-- SCRIPT SQL PARA RECRIAÇÃO DAS TABELAS
-- ============================================

-- Deletar tabelas existentes (cuidado com dados!)
DROP TABLE IF EXISTS itens_venda;
DROP TABLE IF EXISTS venda;
DROP TABLE IF EXISTS compra;
DROP TABLE IF EXISTS produto;
DROP TABLE IF EXISTS cliente;

-- ============================================
-- TABELA: CLIENTE
-- ============================================
CREATE TABLE cliente (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  no_cliente VARCHAR(255) NOT NULL,
  no_situacao VARCHAR(20) DEFAULT 'Ativo',
  no_endereco VARCHAR(255),
  no_bairro VARCHAR(100),
  no_cidade VARCHAR(100),
  no_uf VARCHAR(2),
  no_email VARCHAR(100),
  nu_dddtel VARCHAR(2),
  nu_telefone VARCHAR(9),
  dt_cadastro DATE DEFAULT CURRENT_DATE
);

-- ============================================
-- TABELA: PRODUTO
-- ============================================
CREATE TABLE produto (
  id_produto INT AUTO_INCREMENT PRIMARY KEY,
  no_produto VARCHAR(255) NOT NULL,
  de_produto TEXT,
  no_situacao VARCHAR(20) DEFAULT 'Ativo',
  vl_preco DECIMAL(10,2) NOT NULL,
  qt_estoque INT DEFAULT 0,
  dt_cadastro DATE DEFAULT CURRENT_DATE
);

-- ============================================
-- TABELA: COMPRA
-- ============================================
CREATE TABLE compra (
  id_compra INT AUTO_INCREMENT PRIMARY KEY,
  id_cliente INT,
  dt_compra DATE,
  vl_total DECIMAL(10,2),
  no_situacao VARCHAR(20) DEFAULT 'Aberta',
  de_observacao TEXT,
  dt_cadastro DATE DEFAULT CURRENT_DATE,
  FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
);

-- ============================================
-- TABELA: VENDA
-- ============================================
CREATE TABLE venda (
  id_venda INT AUTO_INCREMENT PRIMARY KEY,
  id_cliente INT,
  dt_venda DATE,
  vl_total DECIMAL(10,2),
  no_situacao VARCHAR(20) DEFAULT 'Aberta',
  de_observacao TEXT,
  dt_cadastro DATE DEFAULT CURRENT_DATE,
  FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
);

-- ============================================
-- TABELA: ITENS_VENDA (Produtos da Venda)
-- ============================================
CREATE TABLE itens_venda (
  id_item INT AUTO_INCREMENT PRIMARY KEY,
  id_venda INT,
  id_produto INT,
  qt_produto INT,
  vl_unitario DECIMAL(10,2),
  vl_subtotal DECIMAL(10,2),
  FOREIGN KEY (id_venda) REFERENCES venda(id_venda),
  FOREIGN KEY (id_produto) REFERENCES produto(id_produto)
);

-- ============================================
-- DADOS DE EXEMPLO (OPCIONAL)
-- ============================================

-- Inserir clientes de exemplo
INSERT INTO cliente (no_cliente, no_situacao, no_endereco, no_bairro, no_cidade, no_uf, no_email, nu_dddtel, nu_telefone, dt_cadastro)
VALUES 
('Cliente 1', 'Ativo', 'Rua A, 123', 'Centro', 'São Paulo', 'SP', 'cliente1@email.com', '11', '987654321', CURDATE()),
('Cliente 2', 'Inativo', 'Rua B, 456', 'Zona Sul', 'Rio de Janeiro', 'RJ', 'cliente2@email.com', '21', '998765432', CURDATE()),
('Cliente 3', 'Ativo', 'Rua C, 789', 'Zona Leste', 'Belo Horizonte', 'MG', 'cliente3@email.com', '31', '999876543', CURDATE());

-- Inserir produtos de exemplo
INSERT INTO produto (no_produto, de_produto, no_situacao, vl_preco, qt_estoque, dt_cadastro)
VALUES 
('Produto A', 'Descrição do Produto A', 'Ativo', 50.00, 100, CURDATE()),
('Produto B', 'Descrição do Produto B', 'Ativo', 75.50, 50, CURDATE()),
('Produto C', 'Descrição do Produto C', 'Inativo', 100.00, 0, CURDATE());
