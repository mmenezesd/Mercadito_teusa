# Sistema Valdosque — Gerenciamento de Clientes e Produtos

Bem-vindo ao sistema **Valdosque**, uma aplicação web para gerenciar clientes e produtos com cadastro, consulta, edição e exclusão (CRUD completo).

---

## 📋 Requisitos

- **XAMPP** (ou Apache + MySQL + PHP 7.4+)
- **MySQL 5.7+**
- **Navegador moderno** (Chrome, Firefox, Edge, Safari)

---

## 🚀 Instalação e Setup

### 1. Preparar a Estrutura de Diretórios

Todos os arquivos já estão em seus devidos lugares:

```
c:\xampp\htdocs\Matheus_Menezes_dos_Santos\Trabalho de Banco de Dados\Valdosque\
├── index.php
├── cliente/
│   ├── clientepage.php       (formulário de cadastro)
│   ├── clientecadastro.php   (processa inserção)
│   ├── clienteconsulta.php   (listagem/consulta)
│   └── conexao.php           (conexão local com BD)
├── produto/
│   ├── produto_page.php      (formulário de cadastro)
│   ├── produtocadastro.php   (processa inserção)
│   ├── produtoconsulta.php   (listagem/consulta)
│   ├── produtoeditar.php     (edita produto)
│   ├── produtoexcluir.php    (exclui produto)
│   └── create_table_produto.sql
├── webservice/
│   └── conexao.php           (conexão central com BD)
└── [outras pastas...]
```

### 2. Criar as Tabelas no MySQL

#### Opção A: Usar phpMyAdmin (mais fácil)

1. Abra **phpMyAdmin** (normalmente em `http://localhost/phpmyadmin`)
2. Selecione o banco de dados **`valdosque_bd`** (se não existir, crie um novo)
3. Vá em **"SQL"** (aba superior)
4. Cole e execute o script abaixo:

```sql
-- Cria tabela CLIENTE (se não existir)
CREATE TABLE IF NOT EXISTS cliente (
  id_cliente INT AUTO_INCREMENT PRIMARY KEY,
  no_cliente VARCHAR(255) NOT NULL,
  no_situacao VARCHAR(20) DEFAULT 'Ativo',
  no_endereco VARCHAR(255),
  no_bairro VARCHAR(100),
  no_cidade VARCHAR(100),
  no_uf VARCHAR(2),
  no_email VARCHAR(100),
  nu_dddtel VARCHAR(2),
  nu_telefone VARCHAR(9),
  dt_cadastro DATE,
  INDEX idx_no_cliente (no_cliente)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Cria tabela PRODUTO (se não existir)
CREATE TABLE IF NOT EXISTS produto (
  id_produto INT AUTO_INCREMENT PRIMARY KEY,
  no_produto VARCHAR(255) NOT NULL,
  de_produto TEXT,
  no_situacao VARCHAR(20) DEFAULT 'Ativo',
  vl_preco DECIMAL(10,2) DEFAULT 0.00,
  qt_estoque INT DEFAULT 0,
  dt_cadastro DATE,
  INDEX idx_no_produto (no_produto)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

#### Opção B: Importar via linha de comando

Abra PowerShell/CMD na pasta do projeto e execute:

```bash
mysql -u root -p valdosque_bd < "produto\create_table_produto.sql"
```

(Se não tiver senha, omita `-p`)

### 3. Verificar Conexão com BD

Abra no navegador:
```
http://localhost/phpmyadmin
```

- Verifique se o banco `valdosque_bd` existe
- Verifique se as tabelas `cliente` e `produto` foram criadas com sucesso

---

## 📱 Como Usar o Sistema

### Página Inicial
```
http://localhost/Matheus_Menezes_dos_Santos/Trabalho%20de%20Banco%20de%20Dados/Valdosque/
```

### Módulo CLIENTE

#### Cadastrar Cliente
1. Acesse: `http://localhost/.../cliente/clientepage.php`
2. Preencha os campos:
   - **Nome** (obrigatório)
   - **Situação** (Ativo/Inativo)
   - **Endereço** (obrigatório)
   - **Bairro, Cidade, UF**
   - **Email** (obrigatório, será validado)
   - **DDD** (2 dígitos)
   - **Telefone** (8-9 dígitos)
3. Clique em **"Gravar"**
4. Se sucesso, será redirecionado com confirmação

#### Consultar Clientes
1. Acesse: `http://localhost/.../cliente/clienteconsulta.php`
2. Digite parte do nome para pesquisar (opcional)
3. Clique em **"Consultar"**
4. Veja lista de clientes com opções para **Excluir**

### Módulo PRODUTO

#### Cadastrar Produto
1. Acesse: `http://localhost/.../produto/produto_page.php`
2. Preencha os campos:
   - **Nome do Produto** (obrigatório)
   - **Descrição** (textarea, opcional)
   - **Situação** (Ativo/Inativo)
   - **Preço** (numérico, obrigatório)
   - **Quantidade em Estoque** (inteiro, obrigatório)
3. Clique em **"Gravar"**

#### Consultar Produtos
1. Acesse: `http://localhost/.../produto/produtoconsulta.php`
2. Digite parte do nome para pesquisar (opcional)
3. Clique em **"Pesquisar"**
4. Veja lista com preço formatado, estoque e data

#### Editar Produto
1. Na página de consulta, clique no botão **"Editar"** de um produto
2. Modifique os campos desejados
3. Clique em **"Salvar"**

#### Excluir Produto
1. Na página de consulta, clique em **"Excluir"** do produto desejado
2. Confirme a exclusão no pop-up que aparecer
3. O produto será removido do banco

---

## 🔒 Segurança

### O que foi implementado

- ✅ **Prepared Statements**: Todas as queries usam prepared statements para prevenir SQL injection
- ✅ **Validação de Entrada**: Email, telefone, preço e quantidade são validados no servidor
- ✅ **Sanitização de Output**: Dados exibidos são escapados com `htmlspecialchars()`
- ✅ **Logging de Erros**: Erros de banco são registrados no log do servidor, não exibidos ao usuário
- ✅ **Confirmação de Exclusão**: Pop-up JavaScript pede confirmação antes de deletar

### O que ainda pode melhorar

- ⚠️ **CSRF Token**: Adicionar token CSRF em formulários (futuro)
- ⚠️ **Autenticação/Login**: Adicionar controle de acesso por usuário
- ⚠️ **Rate Limiting**: Limitar requisições repetidas (proteção contra brute force)
- ⚠️ **HTTPS**: Usar SSL em produção

---

## 🧪 Testes Rápidos

### Teste 1: Cadastro de Cliente
1. Acesse `http://localhost/.../cliente/clientepage.php`
2. Preencha:
   - Nome: `João Silva`
   - Email: `joao@example.com`
   - Telefone: `11987654321` (DDD: 11, Telefone: 987654321)
3. Clique Gravar → deve aparecer "Cadastro realizado com sucesso"

### Teste 2: Validação de Email Inválido
1. Acesse `http://localhost/.../cliente/clientepage.php`
2. Preencha:
   - Nome: `Maria`
   - Email: `email_invalido` (sem @)
3. Clique Gravar → deve aparecer "Email inválido!"

### Teste 3: Cadastro de Produto
1. Acesse `http://localhost/.../produto/produto_page.php`
2. Preencha:
   - Nome: `Notebook Dell`
   - Preço: `1500.00`
   - Quantidade: `5`
3. Clique Gravar → deve aparecer "Produto cadastrado com sucesso"

### Teste 4: Listar Produtos
1. Acesse `http://localhost/.../produto/produtoconsulta.php`
2. Pesquise por `Notebook`
3. Clique Pesquisar → deve ver o produto com preço formatado

### Teste 5: Editar Produto
1. Na consulta, clique Editar no produto
2. Altere a quantidade para `10`
3. Clique Salvar → deve voltar à lista com confirmação

### Teste 6: Excluir Produto
1. Na consulta, clique Excluir
2. Confirme exclusão → produto é removido

---

## 🛠️ Troubleshooting

### Erro: "Banco de dados conectado com erro"
- **Causa**: MySQL não está rodando ou credenciais estão erradas
- **Solução**: 
  - Abra XAMPP Control Panel
  - Clique em "Start" ao lado de "MySQL"
  - Aguarde até ficar verde

### Erro: "Tabela não existe"
- **Causa**: Você não executou o script SQL
- **Solução**: Volte à seção "Criar as Tabelas no MySQL" e execute os comandos

### Campo obrigatório vazio redireciona, mas sem mensagem
- **Causa**: Validação JavaScript ou servidor não executa JavaScript
- **Solução**: Abra o console do navegador (F12) para ver alertas/erros

### Preço não aparece com formato correto (sem casas decimais)
- **Causa**: Tipo de campo `vl_preco` não é DECIMAL
- **Solução**: Verifique no phpMyAdmin o tipo de coluna (deve ser `DECIMAL(10,2)`)

### Erro de conexão ao entrar em consulta
- **Causa**: `../webservice/conexao.php` não pode acessar o arquivo correto
- **Solução**: Verifique se a pasta `webservice/conexao.php` existe no local correto

---

## 📁 Estrutura de Arquivos Importante

```
Valdosque/
├── cliente/
│   ├── conexao.php              ← Conexão local (pode remover, usa ../webservice/)
│   ├── clientecadastro.php      ← Processa POST do formulário
│   ├── clienteconsulta.php      ← Lista clientes
│   └── clientepage.php          ← Formulário de cadastro
├── produto/
│   ├── create_table_produto.sql ← Script para criar tabela (USE ISSO!)
│   ├── produto_page.php         ← Formulário de cadastro
│   ├── produtocadastro.php      ← Processa inserção
│   ├── produtoconsulta.php      ← Lista produtos
│   ├── produtoeditar.php        ← Editar + atualizar
│   └── produtoexcluir.php       ← Excluir por ID
└── webservice/
    └── conexao.php              ← Conexão centralizada (USAR ESTA!)
```

---

## 🎨 Estilos

O sistema usa **Bootstrap 5.3.8** para styling. Todos os formulários têm:
- Cores consistentes (fundo roxo claro para cards de dados)
- Responsividade mobile
- Botões com cores semânticas (verde=sucesso, vermelho=perigo, azul=info)

---

## 📞 Suporte

Se tiver dúvidas:
1. Verifique os logs do Apache/MySQL em `C:\xampp\apache\logs\` ou `C:\xampp\mysql\data\`
2. Abra o console do navegador (F12) e procure por erros JavaScript
3. Verifique se as tabelas existem em phpMyAdmin

---

## ✅ Checklist Final

- [ ] MySQL está rodando (XAMPP Control Panel)
- [ ] Banco de dados `valdosque_bd` existe (phpMyAdmin)
- [ ] Tabelas `cliente` e `produto` foram criadas
- [ ] Página inicial carrega sem erro: `http://localhost/.../Valdosque/`
- [ ] Cadastro de cliente funciona
- [ ] Consulta de cliente lista registros
- [ ] Cadastro de produto funciona
- [ ] Consulta, edição e exclusão de produtos funcionam

---

**Versão**: 1.0  
**Data**: 10 de novembro de 2025  
**Desenvolvedor**: Equipe Valdosque
