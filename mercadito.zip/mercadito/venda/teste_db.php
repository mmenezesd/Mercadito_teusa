<?php
// Arquivo de diagnóstico: lista tabelas e mostra CREATE TABLE de tabelas relevantes
// Coloque este arquivo na pasta 'venda' e abra no navegador para verificar o banco usado pela aplicação.

include "conexao.php";
?>
<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Teste DB - Valdosque</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
</head>
<body class="p-4">
  <div class="container">
    <h1 class="mb-3">Diagnóstico do banco (valdosque_bd)</h1>
    <div class="card mb-3">
      <div class="card-body">
        <h5>Tabelas encontradas</h5>
        <pre>
<?php
$res = mysqli_query($conn, "SHOW TABLES");
if (!$res) {
    echo 'Erro ao listar tabelas: ' . mysqli_error($conn);
} else {
    $has = false;
    while ($row = mysqli_fetch_row($res)) {
        echo $row[0] . "\n";
        $has = true;
    }
    if (!$has) echo "(Nenhuma tabela encontrada)\n";
}
?>
        </pre>
      </div>
    </div>

    <?php
    $tabelas = ['venda','itens_venda','cliente','produto'];
    foreach ($tabelas as $t) {
        echo '<div class="card mb-3">\n';
        echo '<div class="card-body">\n';
        echo '<h5>SHOW CREATE TABLE ' . htmlspecialchars($t) . '</h5>\n';

        $sql = "SHOW CREATE TABLE `" . $t . "`";
        $r = @mysqli_query($conn, $sql);
        if ($r && $row = mysqli_fetch_row($r)) {
            // Resultado: [Table, Create Table]
            echo '<pre>' . htmlspecialchars($row[1]) . '</pre>\n';
        } else {
            echo '<div class="alert alert-warning">Tabela <strong>' . htmlspecialchars($t) . '</strong> não encontrada ou erro: ' . htmlspecialchars(mysqli_error($conn)) . '</div>\n';
        }
        echo '</div>\n';
        echo '</div>\n';
    }
    ?>

    <div class="mt-3">
      <a href="venda_page.php" class="btn btn-primary">Abrir formulário de venda</a>
      <a href="../index.php" class="btn btn-secondary">Voltar ao sistema</a>
    </div>

  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
