<?php include "conexao.php"?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Editar Venda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col">

<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  if (!isset($_GET['id_venda']) || !ctype_digit($_GET['id_venda'])) {
    echo '<script>alert("ID inválido."); window.location.href = "vendaconsulta.php";</script>';
    exit;
  }

  $id = (int) $_GET['id_venda'];
  $sql = "SELECT id_venda, id_cliente, dt_venda, vl_total, no_situacao, de_observacao FROM venda WHERE id_venda = ? LIMIT 1";
  $stmt = mysqli_prepare($conn, $sql);
  if ($stmt === false) {
    error_log('Prepare failed in vendaeditar.php (GET): ' . mysqli_error($conn));
    echo '<script>alert("Erro na consulta."); window.location.href = "vendaconsulta.php";</script>';
    exit;
  }
  mysqli_stmt_bind_param($stmt, 'i', $id);
  mysqli_stmt_execute($stmt);
  $res = mysqli_stmt_get_result($stmt);
  $row = mysqli_fetch_assoc($res);
  mysqli_stmt_close($stmt);

  if (!$row) {
    echo '<script>alert("Venda não encontrada."); window.location.href = "vendaconsulta.php";</script>';
    exit;
  }

  $id_cliente = (int)$row['id_cliente'];
  $dt_venda = $row['dt_venda'];
  $vl_total = $row['vl_total'];
  $no_situacao = $row['no_situacao'];
  $de_observacao = htmlspecialchars($row['de_observacao']);

  echo '<div class="card w-75" style="margin:auto; margin-top:20px;">';
  echo '<div class="card-body title text-center bg-dark text-white"><h2>Editar Venda</h2></div>';
  echo '<div class="card-body p-3" style="background-color: #bfbafa;">';
  echo '<form action="vendaeditar.php" method="POST">';
  echo '<input type="hidden" name="id_venda" value="'. $id .'">';

  echo '<div class="mb-3"><label class="form-label"><strong>ID Cliente</strong></label>'; 
  echo '<input type="number" name="id_cliente" class="form-control" value="'. $id_cliente .'" required></div>';

  echo '<div class="mb-3"><label class="form-label"><strong>Data Venda</strong></label>'; 
  echo '<input type="date" name="dt_venda" class="form-control" value="'. $dt_venda .'" required></div>';

  echo '<div class="mb-3"><label class="form-label"><strong>Valor Total</strong></label>'; 
  echo '<input type="number" step="0.01" min="0" name="vl_total" class="form-control" value="'. $vl_total .'"></div>';

  echo '<div class="mb-3"><label class="form-label"><strong>Situação</strong></label>'; 
  echo '<select name="no_situacao" class="form-control">';
  echo '<option value="Aberta"'.($no_situacao==='Aberta'?' selected':'').'>Aberta</option>';
  echo '<option value="Fechada"'.($no_situacao==='Fechada'?' selected':'').'>Fechada</option>';
  echo '<option value="Cancelada"'.($no_situacao==='Cancelada'?' selected':'').'>Cancelada</option>';
  echo '</select></div>';

  echo '<div class="mb-3"><label class="form-label"><strong>Observação</strong></label>'; 
  echo '<textarea name="de_observacao" class="form-control" rows="3">'. $de_observacao .'</textarea></div>';

  echo '<div class="mb-3">';
  echo '<button class="btn btn-success btn-sm" type="submit">Salvar</button> ';
  echo '<a href="vendaconsulta.php" class="btn btn-secondary btn-sm">Cancelar</a>';
  echo '</div>';

  echo '</form></div></div>';

  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = isset($_POST['id_venda']) && ctype_digit($_POST['id_venda']) ? (int)$_POST['id_venda'] : 0;
  $id_cliente = isset($_POST['id_cliente']) && ctype_digit($_POST['id_cliente']) ? (int)$_POST['id_cliente'] : 0;
  $dt_venda = isset($_POST['dt_venda']) ? trim($_POST['dt_venda']) : '';
  $vl_total = isset($_POST['vl_total']) ? trim($_POST['vl_total']) : '';
  $no_situacao = isset($_POST['no_situacao']) ? trim($_POST['no_situacao']) : 'Aberta';
  $de_observacao = isset($_POST['de_observacao']) ? trim($_POST['de_observacao']) : '';

  if ($id <= 0 || $id_cliente <= 0 || $dt_venda === '') {
    echo '<script>alert("Dados obrigatórios faltando."); window.location.href = "vendaconsulta.php";</script>';
    exit;
  }

  if (!is_numeric($vl_total) || $vl_total < 0) {
    echo '<script>alert("Valor inválido."); window.location.href = "vendaeditar.php?id_venda=' . $id . '";</script>';
    exit;
  }

  $sql = "UPDATE venda SET id_cliente = ?, dt_venda = ?, vl_total = ?, no_situacao = ?, de_observacao = ? WHERE id_venda = ?";
  $stmt = mysqli_prepare($conn, $sql);
  if ($stmt === false) {
    error_log('Prepare failed in vendaeditar.php (POST): ' . mysqli_error($conn));
    echo '<script>alert("Erro ao atualizar."); window.location.href = "vendaconsulta.php";</script>';
    exit;
  }

  $vl_total_f = (float)$vl_total;
  mysqli_stmt_bind_param($stmt, 'isdssi', $id_cliente, $dt_venda, $vl_total_f, $no_situacao, $de_observacao, $id);

  if (mysqli_stmt_execute($stmt)) {
    echo '<script>alert("Venda atualizada com sucesso."); window.location.href = "vendaconsulta.php";</script>';
  } else {
    error_log('Update failed in vendaeditar.php: ' . mysqli_stmt_error($stmt));
    echo '<script>alert("Erro ao atualizar."); window.location.href = "vendaeditar.php?id_venda=' . $id . '";</script>';
  }

  mysqli_stmt_close($stmt);
}
?>

        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  </body>
</html>
