<?php include "../webservice/conexao.php"?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <title>Cadastro Venda</title>
  </head>
  <body>
    <?php
      $id_cliente = isset($_POST['id_cliente']) ? trim($_POST['id_cliente']) : '';
      $dt_venda = isset($_POST['dt_venda']) ? trim($_POST['dt_venda']) : '';
      $no_situacao = isset($_POST['no_situacao']) ? trim($_POST['no_situacao']) : 'Aberta';
      $de_observacao = isset($_POST['de_observacao']) ? trim($_POST['de_observacao']) : '';
      $id_produtos = isset($_POST['id_produto']) ? $_POST['id_produto'] : [];
      $quantidades = isset($_POST['qt_produto']) ? $_POST['qt_produto'] : [];
      $precos_unitarios = isset($_POST['vl_unitario']) ? $_POST['vl_unitario'] : [];
      $subtotais = isset($_POST['vl_subtotal']) ? $_POST['vl_subtotal'] : [];
      $vl_total = isset($_POST['vl_total']) ? trim($_POST['vl_total']) : '0';
      $dt_cadastro = date('Y-m-d');

      // Validações básicas
      if ($id_cliente === '' || $dt_venda === '' || empty($id_produtos)) {
        echo '<script>alert("Preencha cliente, data e pelo menos um produto!"); window.location.href = "venda_page.php";</script>';
        exit;
      }

      if (!ctype_digit($id_cliente)) {
        echo '<script>alert("ID Cliente inválido!"); window.location.href = "venda_page.php";</script>';
        exit;
      }

      if (!is_numeric($vl_total) || $vl_total < 0) {
        echo '<script>alert("Valor total inválido!"); window.location.href = "venda_page.php";</script>';
        exit;
      }

      try {
        // Inserir venda
        $id_cliente_int = (int) $id_cliente;
        $vl_total_float = (float) $vl_total;
        $no_situacao = mysqli_real_escape_string($conn, $no_situacao);
        $de_observacao = mysqli_real_escape_string($conn, $de_observacao);
        $dt_cadastro_db = date('Y-m-d');

        // DEBUG: exibir SQL
        error_log('SQL Venda: INSERT INTO venda (id_cliente, dt_venda, vl_total, no_situacao, de_observacao, dt_cadastro) VALUES (' . $id_cliente_int . ', ' . $dt_venda . ', ' . $vl_total_float . ', ' . $no_situacao . ', ' . $de_observacao . ', ' . $dt_cadastro_db . ')');

        $sql_venda = "INSERT INTO venda (id_cliente, dt_venda, vl_total, no_situacao, de_observacao, dt_cadastro) 
                      VALUES ($id_cliente_int, '$dt_venda', $vl_total_float, '$no_situacao', '$de_observacao', '$dt_cadastro_db')";
        
        if (!mysqli_query($conn, $sql_venda)) {
          throw new Exception('Erro ao inserir venda: ' . mysqli_error($conn) . ' | SQL: ' . $sql_venda);
        }

        $id_venda = mysqli_insert_id($conn);

        if ($id_venda <= 0) {
          throw new Exception('Erro: ID da venda não foi gerado.');
        }

        // Inserir itens da venda
        for ($i = 0; $i < count($id_produtos); $i++) {
          $id_prod = (int) $id_produtos[$i];
          $qtd = (int) $quantidades[$i];
          $preco_unit = (float) $precos_unitarios[$i];
          $subtot = (float) $subtotais[$i];

          if ($id_prod <= 0 || $qtd <= 0) {
            throw new Exception('Produto ou quantidade inválidos.');
          }

          $sql_item = "INSERT INTO itens_venda (id_venda, id_produto, qt_produto, vl_unitario, vl_subtotal) 
                       VALUES ($id_venda, $id_prod, $qtd, $preco_unit, $subtot)";
          
          if (!mysqli_query($conn, $sql_item)) {
            throw new Exception('Erro ao inserir item: ' . mysqli_error($conn));
          }
        }

        echo '<script>alert("Venda cadastrada com sucesso (ID: '.$id_venda.')"); window.location.href = "vendaconsulta.php";</script>';
      } catch (Exception $e) {
        error_log('Erro em vendacadastro.php: ' . $e->getMessage());
        echo '<script>alert("Erro ao registrar venda: ' . addslashes($e->getMessage()) . '"); window.location.href = "venda_page.php";</script>';
      }
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  </body>
</html>
