<?php include "conexao.php"?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Detalhes Venda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card w-100" style="margin-top:20px;">
            <div class="card-body title text-center bg-dark text-white">
              <h2 class="card-title">Detalhes da Venda</h2>
            </div>

            <?php
              if (!isset($_GET['id_venda']) || !ctype_digit($_GET['id_venda'])) {
                echo '<div class="alert alert-danger m-3">ID inválido.</div>';
              } else {
                $id_venda = (int) $_GET['id_venda'];

                // Buscar dados da venda
                $sql_venda = "SELECT v.id_venda, v.id_cliente, v.dt_venda, v.vl_total, v.no_situacao, v.de_observacao, 
                              c.no_cliente FROM venda v 
                              LEFT JOIN cliente c ON v.id_cliente = c.id_cliente 
                              WHERE v.id_venda = ?";
                $stmt = mysqli_prepare($conn, $sql_venda);
                mysqli_stmt_bind_param($stmt, 'i', $id_venda);
                mysqli_stmt_execute($stmt);
                $res = mysqli_stmt_get_result($stmt);
                $venda = mysqli_fetch_assoc($res);
                mysqli_stmt_close($stmt);

                if (!$venda) {
                  echo '<div class="alert alert-warning m-3">Venda não encontrada.</div>';
                } else {
                  $dt_venda = date('d/m/Y', strtotime($venda['dt_venda']));
                  $vl_total_fmt = number_format($venda['vl_total'], 2, ',', '.');

                  echo '<div class="card-body p-3">';
                  echo '<div class="row mb-3">';
                  echo '<div class="col-md-3"><strong>ID Venda:</strong> ' . $venda['id_venda'] . '</div>';
                  echo '<div class="col-md-3"><strong>Cliente:</strong> ' . htmlspecialchars($venda['no_cliente']) . '</div>';
                  echo '<div class="col-md-3"><strong>Data:</strong> ' . $dt_venda . '</div>';
                  echo '<div class="col-md-3"><strong>Situação:</strong> ' . htmlspecialchars($venda['no_situacao']) . '</div>';
                  echo '</div>';
                  echo '<div class="row mb-3">';
                  echo '<div class="col-md-12"><strong>Observação:</strong> ' . htmlspecialchars($venda['de_observacao']) . '</div>';
                  echo '</div>';

                  // Buscar itens da venda
                  $sql_itens = "SELECT iv.id_item, iv.id_produto, p.no_produto, iv.qt_produto, iv.vl_unitario, iv.vl_subtotal 
                                FROM itens_venda iv 
                                LEFT JOIN produto p ON iv.id_produto = p.id_produto 
                                WHERE iv.id_venda = ? 
                                ORDER BY iv.id_item";
                  $stmt_itens = mysqli_prepare($conn, $sql_itens);
                  mysqli_stmt_bind_param($stmt_itens, 'i', $id_venda);
                  mysqli_stmt_execute($stmt_itens);
                  $res_itens = mysqli_stmt_get_result($stmt_itens);

                  echo '<h5 class="mt-3 mb-3">Produtos</h5>';
                  echo '<table class="table table-bordered">';
                  echo '<thead class="table-light"><tr><th>Produto</th><th class="text-center">Quantidade</th><th class="text-right">Preço Unit.</th><th class="text-right">Subtotal</th></tr></thead>';
                  echo '<tbody>';

                  while ($item = mysqli_fetch_assoc($res_itens)) {
                    $preco_fmt = number_format($item['vl_unitario'], 2, ',', '.');
                    $subtotal_fmt = number_format($item['vl_subtotal'], 2, ',', '.');
                    echo '<tr>';
                    echo '<td>' . htmlspecialchars($item['no_produto']) . '</td>';
                    echo '<td class="text-center">' . $item['qt_produto'] . '</td>';
                    echo '<td class="text-right">R$ ' . $preco_fmt . '</td>';
                    echo '<td class="text-right">R$ ' . $subtotal_fmt . '</td>';
                    echo '</tr>';
                  }

                  echo '</tbody>';
                  echo '</table>';

                  echo '<div class="row mt-3">';
                  echo '<div class="col-md-9 text-right" style="text-align:right;"><strong>Total:</strong></div>';
                  echo '<div class="col-md-3" style="text-align:right;"><strong>R$ ' . $vl_total_fmt . '</strong></div>';
                  echo '</div>';

                  mysqli_stmt_close($stmt_itens);
                }
              }
            ?>

            <div class="card-body">
              <a href="vendaconsulta.php" class="btn btn-primary btn-sm">Voltar</a>
            </div>

          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  </body>
</html>
