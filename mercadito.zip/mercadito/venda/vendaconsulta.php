<?php include "conexao.php"; ?>
<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Consulta Venda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
    <script>
      function checkDelete(){
        return confirm('Confirma exclusão?');
      }
    </script>
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card w-100" style="margin-top:20px;">
            <div class="card-body title text-center bg-dark text-white">
              <h1 class="card-title">Consulta Venda</h1>
            </div>
            <div class="card-body" style="background-color:#7b7e7c;">
              <form action="vendaconsulta.php" method="POST" class="row g-2 align-items-center">
                <div class="col-auto">
                  <label for="id_cliente" class="form-label text-white">ID Cliente</label>
                </div>
                <div class="col-auto">
                  <input type="number" name="id_cliente" id="id_cliente" class="form-control" placeholder="Pesquisar por ID">
                </div>
                <div class="col-auto">
                  <button class="btn btn-success btn-sm" type="submit">Pesquisar</button>
                  <a href="venda_page.php" class="btn btn-primary btn-sm">Novo</a>
                  <a href="../index.php" class="btn btn-dark btn-sm">Home</a>
                <div class="card-body">
                  <?php
                    $pesquisar = '';
                    if (isset($_POST['id_cliente'])) {
                      $pesquisar = trim($_POST['id_cliente']);
                    }

                    if ($pesquisar !== '' && !ctype_digit($pesquisar)) {
                      echo '<div class="alert alert-warning">ID inválido.</div>';
                    } else {
                      // Qualify table with database to avoid ambiguity if multiple schemas exist on the server
                      // selecionar usando alias para compatibilidade com código que usa `id_venda`
                      $sql = "SELECT id_registro AS id_venda, id_cliente, dt_venda, vl_total, no_situacao FROM `valdosque_bd`.`venda` WHERE 1=1";

                      
                      if ($pesquisar !== '') {
                        $sql .= " AND id_cliente = ?";
                      }
                      $sql .= " ORDER BY dt_venda DESC";

                      $result = false;

                      if ($pesquisar !== '') {
                        $stmt = mysqli_prepare($conn, $sql);
                        if ($stmt === false) {
                          echo '<div class="alert alert-danger">Erro na preparação da consulta: ' . htmlspecialchars(mysqli_error($conn)) . '</div>';
                        } else {
                          $pesquisar_int = (int) $pesquisar;
                          mysqli_stmt_bind_param($stmt, 'i', $pesquisar_int);
                          if (!mysqli_stmt_execute($stmt)) {
                            echo '<div class="alert alert-danger">Erro ao executar consulta: ' . htmlspecialchars(mysqli_stmt_error($stmt)) . '</div>';
                            mysqli_stmt_close($stmt);
                          } else {
                            $result = mysqli_stmt_get_result($stmt);
                          }
                        }
                      } else {
                        $res = mysqli_query($conn, $sql);
                        if ($res === false) {
                          // mostrar erro e o SQL para debug
                          echo '<div class="alert alert-danger">Erro na consulta: ' . htmlspecialchars(mysqli_error($conn)) . '<br><small>SQL: ' . htmlspecialchars($sql) . '</small></div>';
                        } else {
                          $result = $res;
                        }
                      }

                      if ($result && mysqli_num_rows($result) > 0) {
                        echo '<table class="table table-bordered">';
                        echo '<thead class="table-dark"><tr><th>ID Venda</th><th>ID Cliente</th><th>Data</th><th>Valor</th><th>Situação</th><th>Ações</th></tr></thead>';
                        echo '<tbody>';

                        while ($row = mysqli_fetch_assoc($result)) {
                          $id = $row['id_venda'];
                          $id_cli = $row['id_cliente'];
                          $dt = $row['dt_venda'] ? date('d/m/Y', strtotime($row['dt_venda'])) : '';
                          $vl = number_format($row['vl_total'], 2, ',', '.');
                          $sit = htmlspecialchars($row['no_situacao']);

                          echo "<tr>";
                          echo "<td class='text-center'>" . $id . "</td>";
                          echo "<td class='text-center'>" . $id_cli . "</td>";
                          echo "<td class='text-center'>" . $dt . "</td>";
                          echo "<td class='text-right'>R$ " . $vl . "</td>";
                          echo "<td class='text-center'>" . $sit . "</td>";
                          echo "<td class='text-center'>
                                  <a href='vendaexcluir.php?id_venda=" . $id . "' class='btn btn-sm btn-danger' onclick='return checkDelete()'>Excluir</a>
                                </td>";
                          echo "</tr>";
                        }

                        echo '</tbody></table>';
                      } else {
                        echo '<div class="alert alert-info">Nenhum registro encontrado.</div>';
                      }

                      if (isset($stmt) && $stmt !== false) {
                        mysqli_stmt_close($stmt);
                      }
                    }
          ?>
        </div>

          </div>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  </body>
</html>
