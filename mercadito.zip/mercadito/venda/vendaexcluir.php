<?php include "conexao.php"?>
<?php
  // aceitar parâmetro id_venda para compatibilidade com o frontend
  if (!isset($_GET['id_venda']) || !ctype_digit($_GET['id_venda'])) {
    echo '<script>alert("ID inválido."); window.location.href = "vendaconsulta.php";</script>';
    exit;
  }

  $id = (int) $_GET['id_venda'];

  // A tabela `venda` usa a PK `id_registro`; itens_venda.id_venda referencia esse id.
  // Vamos deletar os itens primeiro e depois a venda dentro de uma transação.
  mysqli_begin_transaction($conn);
  try {
    // Deletar itens associados
    $sql_itens = "DELETE FROM itens_venda WHERE id_venda = ?";
    $stmt_itens = mysqli_prepare($conn, $sql_itens);
    if ($stmt_itens === false) {
      throw new Exception('Erro ao preparar exclusão de itens: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_itens, 'i', $id);
    if (!mysqli_stmt_execute($stmt_itens)) {
      throw new Exception('Erro ao excluir itens: ' . mysqli_stmt_error($stmt_itens));
    }
    mysqli_stmt_close($stmt_itens);

    // Deletar venda (coluna PK é id_registro)
    $sql_venda = "DELETE FROM venda WHERE id_registro = ?";
    $stmt_v = mysqli_prepare($conn, $sql_venda);
    if ($stmt_v === false) {
      throw new Exception('Erro ao preparar exclusão da venda: ' . mysqli_error($conn));
    }
    mysqli_stmt_bind_param($stmt_v, 'i', $id);
    if (!mysqli_stmt_execute($stmt_v)) {
      throw new Exception('Erro ao excluir venda: ' . mysqli_stmt_error($stmt_v));
    }
    mysqli_stmt_close($stmt_v);

    mysqli_commit($conn);
    echo '<script>alert("Venda excluída com sucesso."); window.location.href = "vendaconsulta.php";</script>';
  } catch (Exception $e) {
    mysqli_rollback($conn);
    error_log('Erro em vendaexcluir.php: ' . $e->getMessage());
    echo '<script>alert("Erro ao excluir. ' . addslashes($e->getMessage()) . '"); window.location.href = "vendaconsulta.php";</script>';
  }
?>
