<!doctype html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Venda</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card w-100" style="margin:auto; margin-top:20px;">
            <div class="card-body title text-center bg-dark text-white">
              <h1 class="card-title">Cadastro de Venda</h1>
            </div>
            <div class="card-body p-3" style="background-color: #bfbafa;">
              <form action="vendacadastro.php" method="POST" id="formVenda">
                <div class="row">
                  <div class="col-md-4">
                    <label for="id_cliente" class="form-label"><strong>Cliente</strong></label>
                    <select name="id_cliente" id="id_cliente" class="form-control" required>
                      <option value="">-- Selecione um Cliente --</option>
                      <?php
                        include "conexao.php";
                        $sql_clientes = "SELECT id_cliente, no_cliente FROM cliente WHERE no_situacao = 'Ativo' ORDER BY no_cliente";
                        $result_clientes = mysqli_query($conn, $sql_clientes);
                        while ($cliente = mysqli_fetch_assoc($result_clientes)) {
                          echo '<option value="' . $cliente['id_cliente'] . '">' . htmlspecialchars($cliente['no_cliente']) . ' (ID: ' . $cliente['id_cliente'] . ')</option>';
                        }
                      ?>
                    </select>
                  </div>
                  <div class="col-md-4">
                    <label for="dt_venda" class="form-label"><strong>Data Venda</strong></label>
                    <input type="date" class="form-control" name="dt_venda" value="<?php echo date('Y-m-d'); ?>" required>
                  </div>
                  <div class="col-md-4">
                    <label for="no_situacao" class="form-label"><strong>Situação</strong></label>
                    <select name="no_situacao" class="form-control">
                      <option value="Aberta">Aberta</option>
                      <option value="Fechada">Fechada</option>
                      <option value="Cancelada">Cancelada</option>
                    </select>
                  </div>
                </div>

                <hr class="my-3">
                <h5>Produtos</h5>
                <div id="produtos_container">
                  <div class="row produto-linha mb-2" id="produto-0">
                    <div class="col-md-5">
                      <label class="form-label"><strong>Produto</strong></label>
                      <select name="id_produto[]" class="form-control produto-select" required>
                        <option value="">-- Selecione um Produto --</option>
                        <?php
                          $sql_produtos = "SELECT id_produto, no_produto, vl_preco FROM produto WHERE no_situacao = 'Ativo' ORDER BY no_produto";
                          $result_produtos = mysqli_query($conn, $sql_produtos);
                          while ($produto = mysqli_fetch_assoc($result_produtos)) {
                            echo '<option value="' . $produto['id_produto'] . '" data-preco="' . $produto['vl_preco'] . '">' . htmlspecialchars($produto['no_produto']) . ' - R$ ' . number_format($produto['vl_preco'], 2, ',', '.') . '</option>';
                          }
                        ?>
                      </select>
                    </div>
                    <div class="col-md-2">
                      <label class="form-label"><strong>Quantidade</strong></label>
                      <input type="number" name="qt_produto[]" class="form-control quantidade-input" value="1" min="1" required>
                    </div>
                    <div class="col-md-2">
                      <label class="form-label"><strong>Preço Unit.</strong></label>
                      <input type="number" name="vl_unitario[]" step="0.01" class="form-control preco-input" readonly>
                    </div>
                    <div class="col-md-2">
                      <label class="form-label"><strong>Subtotal</strong></label>
                      <input type="number" name="vl_subtotal[]" step="0.01" class="form-control subtotal-input" readonly>
                    </div>
                    <div class="col-md-1 d-flex align-items-end">
                      <button type="button" class="btn btn-danger btn-sm w-100 remover-produto" style="display:none;">Remover</button>
                    </div>
                  </div>
                </div>

                <div class="row mt-2">
                  <div class="col-md-12">
                    <button type="button" class="btn btn-info btn-sm" onclick="adicionarProduto()">+ Adicionar Produto</button>
                  </div>
                </div>

                <hr class="my-3">
                <div class="row">
                  <div class="col-md-3 offset-md-9">
                    <label class="form-label"><strong>Valor Total</strong></label>
                    <input type="number" name="vl_total" id="vl_total_input" step="0.01" class="form-control" value="0.00" readonly>
                  </div>
                </div>

                <div class="row mt-3">
                  <div class="col-md-12">
                    <label for="de_observacao" class="form-label"><strong>Observação</strong></label>
                    <textarea class="form-control" name="de_observacao" placeholder="Observações" rows="2"></textarea>
                  </div>
                </div>

                <div class="row mt-3">
                  <div class="col-md-12">
                    <button class="btn btn-success btn-sm" type="submit">Gravar Venda</button>
                    <a href="vendaconsulta.php" class="btn btn-primary btn-sm">Consulta</a>
                    <a href="../index.php" class="btn btn-dark btn-sm">Home</a>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script>
      let linhaCount = 1;

      function adicionarProduto() {
        const container = document.getElementById('produtos_container');
        const novaLinha = document.createElement('div');
        novaLinha.className = 'row produto-linha mb-2';
        novaLinha.id = 'produto-' + linhaCount;
        novaLinha.innerHTML = `
          <div class="col-md-5">
            <select name="id_produto[]" class="form-control produto-select" required>
              <option value="">-- Selecione um Produto --</option>
              <?php
                $sql_produtos = "SELECT id_produto, no_produto, vl_preco FROM produto WHERE no_situacao = 'Ativo' ORDER BY no_produto";
                $result_produtos = mysqli_query($conn, $sql_produtos);
                while ($produto = mysqli_fetch_assoc($result_produtos)) {
                  echo '<option value="' . $produto['id_produto'] . '" data-preco="' . $produto['vl_preco'] . '">' . htmlspecialchars($produto['no_produto']) . ' - R$ ' . number_format($produto['vl_preco'], 2, ',', '.') . '</option>';
                }
              ?>
            </select>
          </div>
          <div class="col-md-2">
            <input type="number" name="qt_produto[]" class="form-control quantidade-input" value="1" min="1" required>
          </div>
          <div class="col-md-2">
            <input type="number" name="vl_unitario[]" step="0.01" class="form-control preco-input" readonly>
          </div>
          <div class="col-md-2">
            <input type="number" name="vl_subtotal[]" step="0.01" class="form-control subtotal-input" readonly>
          </div>
          <div class="col-md-1 d-flex align-items-end">
            <button type="button" class="btn btn-danger btn-sm w-100 remover-produto">Remover</button>
          </div>
        `;
        container.appendChild(novaLinha);
        linhaCount++;
        atualizarBotoes();
        atualizarTotais();
      }

      function atualizarBotoes() {
        const linhas = document.querySelectorAll('.produto-linha');
        linhas.forEach((linha, index) => {
          const btnRemover = linha.querySelector('.remover-produto');
          if (linhas.length > 1) {
            btnRemover.style.display = 'block';
          } else {
            btnRemover.style.display = 'none';
          }
          btnRemover.onclick = function() {
            linha.remove();
            atualizarBotoes();
            atualizarTotais();
          };
        });
      }

      function atualizarTotais() {
        let totalGeral = 0;
        document.querySelectorAll('.produto-linha').forEach(linha => {
          const selectProduto = linha.querySelector('.produto-select');
          const qtInput = linha.querySelector('.quantidade-input');
          const precoInput = linha.querySelector('.preco-input');
          const subtotalInput = linha.querySelector('.subtotal-input');
          
          const preco = parseFloat(selectProduto.options[selectProduto.selectedIndex].dataset.preco) || 0;
          const qt = parseInt(qtInput.value) || 0;
          const subtotal = preco * qt;

          precoInput.value = preco.toFixed(2);
          subtotalInput.value = subtotal.toFixed(2);
          totalGeral += subtotal;
        });
        document.getElementById('vl_total_input').value = totalGeral.toFixed(2);
      }

      document.getElementById('produtos_container').addEventListener('change', atualizarTotais);
      document.getElementById('produtos_container').addEventListener('input', atualizarTotais);

      atualizarBotoes();
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
  </body>
</html>